# INPUT NUMBER OF EVEN NUMBERS

n=int(input('Amount: '))
start=0

for i in range(n):
  print(start)
  start+=2
